<?php

namespace MikeySano1040JoinLeave\Event;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\Server;


class MikeySano1040JoinLeave implements Listener
{
    public function onJoin(PlayerJoinEvent $event)
    {
        $player = $event->getPlayer()->getName();
        $event->setJoinMessage("§f[§a-§f] $player");
    }
    public function onLeave(PlayerQuitEvent $event)
    {
        $player = $event->getPlayer()->getName();
        $event->setQuitMessage("§f[§c-§f] $player");
    }
}