<?php

namespace MikeySano1040JoinLeave;

use pocketmine\plugin\PluginBase;
use MikeySano1040JoinLeave\Event\MikeySano1040JoinLeave;

class Main extends PluginBase
{
    protected function onEnable(): void
    {
        $this->getServer()->getPluginManager()->registerEvents(new MikeySano1040JoinLeave(),$this);
    }
}